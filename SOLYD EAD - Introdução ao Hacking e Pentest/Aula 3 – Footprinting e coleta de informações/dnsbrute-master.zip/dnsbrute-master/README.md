# DNSbrute
Simple subdomain DNS bruteforcing in Python for educational porpouses

# Usage
python dnsbrute.py example.com wordlist.txt

[Solyd Treinamentos - Hacking, Pentest, Segurança](https://solyd.com.br/treinamentos)
